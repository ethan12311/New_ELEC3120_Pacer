# Install required libraries with updated versions
!pip install -q PyPDF2 sentence-transformers faiss-cpu transformers
!pip install -q -U huggingface_hub
!pip install -q ipywidgets
!pip install -q sentencepiece
